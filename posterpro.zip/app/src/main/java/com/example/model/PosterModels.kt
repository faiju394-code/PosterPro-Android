package com.example.model

import androidx.compose.ui.graphics.Color
import java.util.UUID

enum class LayerType {
    TEXT, IMAGE, SHAPE, DRAWING, STICKER
}

enum class ShapeType {
    RECTANGLE, CIRCLE, STAR, HEART, TRIANGLE, ARROW, POLYGON
}

enum class CanvasRatio(val title: String, val width: Int, val height: Int) {
    YOUTUBE_THUMBNAIL("YouTube Thumbnail (16:9)", 1280, 720),
    INSTAGRAM_POST("Instagram Post (1:1)", 1080, 1080),
    INSTAGRAM_PORTRAIT("Instagram Portrait (4:5)", 1080, 1350),
    INSTAGRAM_STORY("Instagram Story (9:16)", 1080, 1920),
    YOUTUBE_BANNER("YouTube Banner", 2560, 1440),
    CUSTOM("Custom Pixels", 1000, 1000)
}

data class TextConfig(
    val text: String = "PosterPro Text",
    val fontSize: Float = 48f,
    val textColor: Long = 0xFFFFFFFF,
    val useGradient: Boolean = false,
    val gradientColor2: Long = 0xFFFF0055,
    val fontFamily: String = "Roboto",
    val letterSpacing: Float = 0f,
    val lineHeight: Float = 1.2f,
    val strokeWidth: Float = 0f,
    val strokeColor: Long = 0xFF000000,
    val shadowOffsetX: Float = 4f,
    val shadowOffsetY: Float = 4f,
    val shadowBlur: Float = 8f,
    val shadowColor: Long = 0x88000000,
    val enable3D: Boolean = false,
    val extrusionDepth: Float = 10f,
    val extrusionColor: Long = 0xFF333333,
    val curveAngle: Float = 0f,
    val enableReflection: Boolean = false,
    val reflectionOpacity: Float = 0.3f
)

data class ShapeConfig(
    val shapeType: ShapeType = ShapeType.RECTANGLE,
    val fillColor: Long = 0xFFFF5722,
    val strokeWidth: Float = 0f,
    val strokeColor: Long = 0xFFFFFFFF,
    val cornerRadius: Float = 16f
)

data class OffsetData(val x: Float, val y: Float)

data class DrawSegment(
    val points: List<OffsetData>,
    val color: Long,
    val strokeWidth: Float,
    val isNeon: Boolean,
    val isEraser: Boolean
)

data class DrawingConfig(
    val segments: List<DrawSegment> = emptyList(),
    val strokeColor: Long = 0xFF00E676,
    val strokeWidth: Float = 16f,
    val opacity: Float = 1f,
    val isNeonGlow: Boolean = false,
    val isEraser: Boolean = false
)

data class Layer(
    val id: String = UUID.randomUUID().toString(),
    val name: String = "Layer",
    val type: LayerType,
    var x: Float = 100f,
    var y: Float = 100f,
    var width: Float = 400f,
    var height: Float = 400f,
    var rotation: Float = 0f,
    var scale: Float = 1f,
    var alpha: Float = 1f,
    var isLocked: Boolean = false,
    var isHidden: Boolean = false,
    val textConfig: TextConfig? = null,
    val shapeConfig: ShapeConfig? = null,
    val drawingConfig: DrawingConfig? = null,
    val imageUri: String? = null,
    val stickerName: String? = null
)

data class FilterConfig(
    val brightness: Float = 0f,
    val contrast: Float = 1f,
    val saturation: Float = 1f,
    val hue: Float = 0f,
    val vignette: Float = 0f,
    val noise: Float = 0f
)

data class CanvasState(
    val ratio: CanvasRatio = CanvasRatio.YOUTUBE_THUMBNAIL,
    val customWidth: Int = 1280,
    val customHeight: Int = 720,
    val backgroundType: BackgroundType = BackgroundType.SOLID,
    val backgroundColor: Long = 0xFF1A1A2E,
    val backgroundGradientEnd: Long = 0xFF16213E,
    val backgroundImageUri: String? = null,
    val layers: List<Layer> = emptyList(),
    val selectedLayerId: String? = null,
    val filters: FilterConfig = FilterConfig()
)

enum class BackgroundType {
    TRANSPARENT, SOLID, GRADIENT, IMAGE
}
