package com.example.model

import com.example.R

data class FontItem(
    val id: String,
    val name: String,
    val language: FontLanguage,
    val style: String,
    val fontResId: Int? = null,
    val customUri: String? = null
)

enum class FontLanguage(val displayName: String) {
    ENGLISH("English"),
    HANDWRITING("Handwriting / Script"),
    ASSAMESE("Assamese"),
    DEVANAGARI("Hindi / Devanagari"),
    BENGALI("Bengali"),
    TAMIL("Tamil"),
    TELUGU("Telugu"),
    ARABIC_URDU("Arabic / Urdu"),
    CUSTOM("Custom Imported")
}

object FontLibrary {
    val preloadedFonts = listOf(
        FontItem("roboto", "Roboto", FontLanguage.ENGLISH, "Sans-Serif", R.font.roboto),
        FontItem("pacifico", "Pacifico", FontLanguage.HANDWRITING, "Script / Calligraphy", R.font.pacifico),
        FontItem("caveat", "Caveat", FontLanguage.HANDWRITING, "Casual Handwriting", R.font.caveat),
        FontItem("great_vibes", "Great Vibes", FontLanguage.HANDWRITING, "Elegant Calligraphy", R.font.great_vibes),
        FontItem("dancing_script", "Dancing Script", FontLanguage.HANDWRITING, "Lively Script", R.font.dancing_script),
        FontItem("tiro_bangla", "Tiro Bangla (Assamese)", FontLanguage.ASSAMESE, "Traditional Assamese Serif", R.font.tiro_bangla),
        FontItem("noto_serif_bengali", "Noto Serif Bengali (Assamese)", FontLanguage.ASSAMESE, "Classical Assamese Serif", R.font.noto_serif_bengali),
        FontItem("devanagari", "Noto Sans Devanagari", FontLanguage.DEVANAGARI, "Devanagari Bold", R.font.noto_sans_devanagari),
        FontItem("bengali", "Noto Sans Bengali", FontLanguage.BENGALI, "Bengali Standard", R.font.noto_sans_bengali),
        FontItem("tamil", "Noto Sans Tamil", FontLanguage.TAMIL, "Tamil Modern", R.font.noto_sans_tamil),
        FontItem("telugu", "Noto Sans Telugu", FontLanguage.TELUGU, "Telugu Display", R.font.noto_sans_telugu),
        FontItem("arabic", "Noto Sans Arabic", FontLanguage.ARABIC_URDU, "Arabic / Urdu Script", R.font.noto_sans_arabic)
    )
}
