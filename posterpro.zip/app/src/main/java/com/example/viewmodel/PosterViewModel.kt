package com.example.viewmodel

import androidx.lifecycle.ViewModel
import com.example.model.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

class PosterViewModel : ViewModel() {
    private val _canvasState = MutableStateFlow(CanvasState())
    val canvasState: StateFlow<CanvasState> = _canvasState.asStateFlow()

    private val _customFonts = MutableStateFlow<List<FontItem>>(emptyList())
    val customFonts: StateFlow<List<FontItem>> = _customFonts.asStateFlow()

    val brushColor = MutableStateFlow(0xFF00E676)
    val brushSize = MutableStateFlow(16f)
    val brushOpacity = MutableStateFlow(1f)
    val isNeonGlow = MutableStateFlow(false)
    val isEraser = MutableStateFlow(false)

    private val undoStack = mutableListOf<CanvasState>()
    private val redoStack = mutableListOf<CanvasState>()

    private fun saveStateForUndo() {
        undoStack.add(_canvasState.value)
        if (undoStack.size > 20) undoStack.removeAt(0)
        redoStack.clear()
    }

    fun undo() {
        if (undoStack.isNotEmpty()) {
            val current = _canvasState.value
            val previous = undoStack.removeAt(undoStack.size - 1)
            redoStack.add(current)
            _canvasState.value = previous
        }
    }

    fun redo() {
        if (redoStack.isNotEmpty()) {
            val current = _canvasState.value
            val next = redoStack.removeAt(redoStack.size - 1)
            undoStack.add(current)
            _canvasState.value = next
        }
    }

    fun setCanvasRatio(ratio: CanvasRatio) {
        saveStateForUndo()
        _canvasState.update { 
            it.copy(
                ratio = ratio,
                customWidth = if (ratio != CanvasRatio.CUSTOM) ratio.width else it.customWidth,
                customHeight = if (ratio != CanvasRatio.CUSTOM) ratio.height else it.customHeight
            )
        }
    }

    fun setBackground(type: BackgroundType, color: Long, gradientEnd: Long = color, uri: String? = null) {
        saveStateForUndo()
        _canvasState.update { 
            it.copy(
                backgroundType = type,
                backgroundColor = color,
                backgroundGradientEnd = gradientEnd,
                backgroundImageUri = uri
            )
        }
    }

    fun selectLayer(id: String?) {
        _canvasState.update { it.copy(selectedLayerId = id) }
    }

    fun addTextLayer(text: String = "PosterPro Text") {
        saveStateForUndo()
        val newLayer = Layer(
            name = "Text: ${text.take(10)}",
            type = LayerType.TEXT,
            x = 200f,
            y = 200f,
            width = 400f,
            height = 120f,
            textConfig = TextConfig(text = text)
        )
        _canvasState.update { it.copy(layers = it.layers + newLayer, selectedLayerId = newLayer.id) }
    }

    fun addShapeLayer(shapeType: ShapeType) {
        saveStateForUndo()
        val newLayer = Layer(
            name = "Shape: $shapeType",
            type = LayerType.SHAPE,
            x = 250f,
            y = 250f,
            width = 300f,
            height = 300f,
            shapeConfig = ShapeConfig(shapeType = shapeType)
        )
        _canvasState.update { it.copy(layers = it.layers + newLayer, selectedLayerId = newLayer.id) }
    }

    fun addImageLayer(uri: String) {
        saveStateForUndo()
        val newLayer = Layer(
            name = "Image Layer",
            type = LayerType.IMAGE,
            x = 150f,
            y = 150f,
            width = 500f,
            height = 400f,
            imageUri = uri
        )
        _canvasState.update { it.copy(layers = it.layers + newLayer, selectedLayerId = newLayer.id) }
    }

    fun addDrawingLayer() {
        saveStateForUndo()
        val newLayer = Layer(
            name = "Draw Layer",
            type = LayerType.DRAWING,
            x = 0f,
            y = 0f,
            width = 1280f,
            height = 720f,
            drawingConfig = DrawingConfig()
        )
        _canvasState.update { it.copy(layers = it.layers + newLayer, selectedLayerId = newLayer.id) }
    }

    fun updateDrawingSegments(layerId: String, segments: List<DrawSegment>) {
        _canvasState.update { state ->
            val updatedLayers = state.layers.map { layer ->
                if (layer.id == layerId && layer.type == LayerType.DRAWING) {
                    val dc = layer.drawingConfig ?: DrawingConfig()
                    layer.copy(drawingConfig = dc.copy(segments = segments))
                } else {
                    layer
                }
            }
            state.copy(layers = updatedLayers)
        }
    }

    fun updateLayer(updatedLayer: Layer) {
        _canvasState.update { state ->
            val updatedLayers = state.layers.map { if (it.id == updatedLayer.id) updatedLayer else it }
            state.copy(layers = updatedLayers)
        }
    }

    fun importCustomFont(fontName: String, uriString: String) {
        val customFont = FontItem(
            id = "custom_${System.currentTimeMillis()}",
            name = fontName,
            language = FontLanguage.CUSTOM,
            style = "Custom TTF/OTF",
            customUri = uriString
        )
        _customFonts.update { it + customFont }
    }

    fun deleteSelectedLayer() {
        val selectedId = _canvasState.value.selectedLayerId ?: return
        saveStateForUndo()
        _canvasState.update { state ->
            state.copy(
                layers = state.layers.filter { it.id != selectedId },
                selectedLayerId = null
            )
        }
    }

    fun duplicateSelectedLayer() {
        val state = _canvasState.value
        val selected = state.layers.find { it.id == state.selectedLayerId } ?: return
        saveStateForUndo()
        val duplicate = selected.copy(
            id = java.util.UUID.randomUUID().toString(),
            name = "${selected.name} (Copy)",
            x = selected.x + 30f,
            y = selected.y + 30f
        )
        _canvasState.update { it.copy(layers = it.layers + duplicate, selectedLayerId = duplicate.id) }
    }

    fun toggleLockSelected() {
        val state = _canvasState.value
        val selected = state.layers.find { it.id == state.selectedLayerId } ?: return
        updateLayer(selected.copy(isLocked = !selected.isLocked))
    }

    fun toggleHideSelected() {
        val state = _canvasState.value
        val selected = state.layers.find { it.id == state.selectedLayerId } ?: return
        updateLayer(selected.copy(isHidden = !selected.isHidden))
    }

    fun moveLayerForward() {
        val state = _canvasState.value
        val index = state.layers.indexOfFirst { it.id == state.selectedLayerId }
        if (index < 0 || index >= state.layers.size - 1) return
        saveStateForUndo()
        val mutableList = state.layers.toMutableList()
        val item = mutableList.removeAt(index)
        mutableList.add(index + 1, item)
        _canvasState.update { it.copy(layers = mutableList) }
    }

    fun moveLayerBackward() {
        val state = _canvasState.value
        val index = state.layers.indexOfFirst { it.id == state.selectedLayerId }
        if (index <= 0) return
        saveStateForUndo()
        val mutableList = state.layers.toMutableList()
        val item = mutableList.removeAt(index)
        mutableList.add(index - 1, item)
        _canvasState.update { it.copy(layers = mutableList) }
    }

    fun updateFilters(newFilters: FilterConfig) {
        _canvasState.update { it.copy(filters = newFilters) }
    }

    fun loadTemplate(templateType: String) {
        saveStateForUndo()
        when (templateType) {
            "cyberpunk" -> {
                _canvasState.value = CanvasState(
                    ratio = CanvasRatio.YOUTUBE_THUMBNAIL,
                    customWidth = 1280,
                    customHeight = 720,
                    backgroundType = BackgroundType.GRADIENT,
                    backgroundColor = 0xFF0F0C29,
                    backgroundGradientEnd = 0xFF24243E,
                    layers = listOf(
                        Layer(
                            name = "Title",
                            type = LayerType.TEXT,
                            x = 120f,
                            y = 200f,
                            width = 1040f,
                            height = 180f,
                            textConfig = TextConfig(
                                text = "CYBERPUNK 2077",
                                fontSize = 72f,
                                textColor = 0xFF00FFFF,
                                useGradient = true,
                                gradientColor2 = 0xFFFF007F,
                                enable3D = true,
                                extrusionDepth = 12f,
                                extrusionColor = 0xFF550033
                            )
                        )
                    )
                )
            }
            else -> {}
        }
    }
}
