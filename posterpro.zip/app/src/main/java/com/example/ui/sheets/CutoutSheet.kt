package com.example.ui.sheets

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CutoutSheet(
    onAutoCutout: () -> Unit,
    onManualOutline: () -> Unit,
    onDismiss: () -> Unit
) {
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = Color(0xFF1E1E2C)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
                .navigationBarsPadding(),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text("PicsArt AI Cutout & Eraser", style = MaterialTheme.typography.titleLarge, color = Color.White)

            Text("Automatically remove backgrounds or outline subjects precisely like PicsArt.", color = Color.Gray, style = MaterialTheme.typography.bodyMedium)

            Button(
                onClick = { onAutoCutout(); onDismiss() },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00E676)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Smart AI Background Cutout", color = Color.Black)
            }

            Button(
                onClick = { onManualOutline(); onDismiss() },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2A2A3D)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Manual Outline & Brush Eraser", color = Color.White)
            }
        }
    }
}
