package com.example.ui.sheets

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BrushEditorSheet(
    brushColor: Long,
    brushSize: Float,
    brushOpacity: Float,
    isNeonGlow: Boolean,
    isEraser: Boolean,
    onColorChanged: (Long) -> Unit,
    onSizeChanged: (Float) -> Unit,
    onOpacityChanged: (Float) -> Unit,
    onNeonGlowChanged: (Boolean) -> Unit,
    onEraserChanged: (Boolean) -> Unit,
    onAddNewDrawLayer: () -> Unit,
    onDismiss: () -> Unit
) {
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = Color(0xFF1E1E2C)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(20.dp)
                .navigationBarsPadding(),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text("PicsArt Brush Studio", style = MaterialTheme.typography.titleLarge, color = Color.White)

            // Mode Selector: Draw vs Eraser
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Button(
                    onClick = { onEraserChanged(false) },
                    colors = ButtonDefaults.buttonColors(containerColor = if (!isEraser) Color(0xFF00E676) else Color(0xFF2A2A3D)),
                    modifier = Modifier.weight(1f)
                ) {
                    Text("Brush Mode", color = if (!isEraser) Color.Black else Color.White)
                }
                Button(
                    onClick = { onEraserChanged(true) },
                    colors = ButtonDefaults.buttonColors(containerColor = if (isEraser) Color(0xFFFF5252) else Color(0xFF2A2A3D)),
                    modifier = Modifier.weight(1f)
                ) {
                    Text("Eraser Mode", color = if (isEraser) Color.White else Color.Gray)
                }
            }

            // Brush Size
            Column {
                Text("Brush Size: ${brushSize.toInt()}px", color = Color.White)
                Slider(
                    value = brushSize,
                    onValueChange = onSizeChanged,
                    valueRange = 2f..80f,
                    colors = SliderDefaults.colors(thumbColor = Color(0xFF00E676), activeTrackColor = Color(0xFF00E676))
                )
            }

            // Opacity
            Column {
                Text("Opacity: ${(brushOpacity * 100).toInt()}%", color = Color.White)
                Slider(
                    value = brushOpacity,
                    onValueChange = onOpacityChanged,
                    valueRange = 0.1f..1f,
                    colors = SliderDefaults.colors(thumbColor = Color(0xFF00E676), activeTrackColor = Color(0xFF00E676))
                )
            }

            // Neon Glow Toggle
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Neon Glow Effect", color = Color.White)
                Switch(
                    checked = isNeonGlow,
                    onCheckedChange = onNeonGlowChanged
                )
            }

            // Color Palette
            Text("Preset Colors", color = Color.Gray, style = MaterialTheme.typography.bodySmall)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                val colors = listOf(0xFFFFFFFF, 0xFFFF3366, 0xFF00E676, 0xFF00FFFF, 0xFFFFD700, 0xFF9C27B0)
                colors.forEach { col ->
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .background(Color(col), CircleShape)
                            .clickable { onColorChanged(col) }
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Button(
                onClick = { onAddNewDrawLayer(); onDismiss() },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00E676)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Create New Drawing Layer", color = Color.Black)
            }
        }
    }
}
