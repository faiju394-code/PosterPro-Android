package com.example.ui.sheets

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.example.model.ShapeType

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ShapeEditorSheet(
    onAddShape: (ShapeType) -> Unit,
    onDismiss: () -> Unit
) {
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = Color(0xFF1E1E2C)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
                .navigationBarsPadding(),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text("Select Shape & Geometry", style = MaterialTheme.typography.titleLarge, color = Color.White)

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Button(
                    onClick = { onAddShape(ShapeType.RECTANGLE); onDismiss() },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2A2A3D)),
                    modifier = Modifier.weight(1f)
                ) {
                    Text("Rectangle", color = Color.White)
                }
                Button(
                    onClick = { onAddShape(ShapeType.CIRCLE); onDismiss() },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2A2A3D)),
                    modifier = Modifier.weight(1f)
                ) {
                    Text("Circle", color = Color.White)
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Button(
                    onClick = { onAddShape(ShapeType.STAR); onDismiss() },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2A2A3D)),
                    modifier = Modifier.weight(1f)
                ) {
                    Text("Star", color = Color.White)
                }
                Button(
                    onClick = { onAddShape(ShapeType.TRIANGLE); onDismiss() },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2A2A3D)),
                    modifier = Modifier.weight(1f)
                ) {
                    Text("Triangle", color = Color.White)
                }
            }
        }
    }
}
