package com.example.ui.sheets

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

data class PresetBackground(
    val title: String,
    val color1: Long,
    val color2: Long,
    val isGradient: Boolean
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GalleryPickerSheet(
    onBackgroundSelected: (Long, Long, Boolean) -> Unit,
    onSelectDeviceGallery: (() -> Unit)? = null,
    onDismiss: () -> Unit
) {
    val presetBackgrounds = listOf(
        PresetBackground("Cyberpunk", 0xFF0F0C29, 0xFF24243E, true),
        PresetBackground("Sunset Glow", 0xFFFF5722, 0xFF9C27B0, true),
        PresetBackground("Emerald Matrix", 0xFF003300, 0xFF00E676, true),
        PresetBackground("Royal Gold", 0xFF1A1A2E, 0xFFFFD700, true),
        PresetBackground("Crimson Fire", 0xFFB71C1C, 0xFF212121, true),
        PresetBackground("Electric Cyan", 0xFF101010, 0xFF00FFFF, true),
        PresetBackground("Midnight Blue", 0xFF0F2027, 0xFF203A43, true),
        PresetBackground("Pure White", 0xFFFFFFFF, 0xFFFFFFFF, false)
    )

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = Color(0xFF1E1E2C)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.75f)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                text = "Select Background & Gallery",
                style = MaterialTheme.typography.titleLarge,
                color = Color.White
            )

            if (onSelectDeviceGallery != null) {
                Button(
                    onClick = {
                        onSelectDeviceGallery()
                        onDismiss()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00E676)),
                    modifier = Modifier.fillMaxWidth().height(52.dp)
                ) {
                    Icon(Icons.Default.FolderOpen, contentDescription = null, tint = Color.Black)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Upload from Device / Browse Files", color = Color.Black, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                }
            }

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = "Preset Color & Gradient Backgrounds",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                modifier = Modifier.fillMaxSize(),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(presetBackgrounds) { bg ->
                    val brush = if (bg.isGradient) {
                        Brush.linearGradient(listOf(Color(bg.color1), Color(bg.color2)))
                    } else {
                        Brush.linearGradient(listOf(Color(bg.color1), Color(bg.color1)))
                    }

                    Box(
                        modifier = Modifier
                            .height(90.dp)
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(brush)
                            .clickable {
                                onBackgroundSelected(bg.color1, bg.color2, bg.isGradient)
                                onDismiss()
                            },
                        contentAlignment = Alignment.BottomStart
                    ) {
                        Surface(
                            color = Color.Black.copy(alpha = 0.5f),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(4.dp)
                                .clip(RoundedCornerShape(6.dp))
                        ) {
                            Text(
                                text = bg.title,
                                color = Color.White,
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}
