package com.example.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import com.example.ui.components.*
import com.example.ui.sheets.*
import com.example.viewmodel.PosterViewModel

@Composable
fun EditorScreen(
    viewModel: PosterViewModel,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val state by viewModel.canvasState.collectAsState()
    val customFonts by viewModel.customFonts.collectAsState()
    val brushColor by viewModel.brushColor.collectAsState()
    val brushSize by viewModel.brushSize.collectAsState()
    val brushOpacity by viewModel.brushOpacity.collectAsState()
    val isNeonGlow by viewModel.isNeonGlow.collectAsState()
    val isEraser by viewModel.isEraser.collectAsState()

    var activeTool by remember { mutableStateOf(ActiveTool.NONE) }
    var showLayersSheet by remember { mutableStateOf(false) }
    var showTemplatesSheet by remember { mutableStateOf(false) }
    var showExportSheet by remember { mutableStateOf(false) }
    var showCutoutSheet by remember { mutableStateOf(false) }

    val galleryLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri ->
        if (uri != null) {
            viewModel.addImageLayer(uri.toString())
        }
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            galleryLauncher.launch("image/*")
        }
    }

    val selectedLayer = state.layers.find { it.id == state.selectedLayerId }
    val isDrawingActive = activeTool == ActiveTool.BRUSH || (selectedLayer != null && selectedLayer.type == com.example.model.LayerType.DRAWING)

    Scaffold(
        topBar = {
            TopToolbar(
                onUndo = { viewModel.undo() },
                onRedo = { viewModel.redo() },
                onOpenLayers = { showLayersSheet = true },
                onOpenTemplates = { showTemplatesSheet = true },
                onOpenExport = { showExportSheet = true },
                onBack = onBack
            )
        },
        bottomBar = {
            BottomToolbar(
                activeTool = activeTool,
                onToolSelected = { tool ->
                    activeTool = tool
                    when (tool) {
                        ActiveTool.TEXT -> viewModel.addTextLayer()
                        ActiveTool.BRUSH -> {
                            viewModel.addDrawingLayer()
                        }
                        ActiveTool.CUTOUT -> {
                            showCutoutSheet = true
                        }
                        ActiveTool.IMAGE -> {
                            val permission = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                                Manifest.permission.READ_MEDIA_IMAGES
                            } else {
                                Manifest.permission.READ_EXTERNAL_STORAGE
                            }
                            val hasPermission = ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED
                            if (hasPermission) {
                                galleryLauncher.launch("image/*")
                            } else {
                                permissionLauncher.launch(permission)
                            }
                            activeTool = ActiveTool.NONE
                        }
                        else -> {}
                    }
                }
            )
        },
        containerColor = Color(0xFF1A1A26)
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            CanvasRenderer(
                state = state,
                onSelectLayer = { id -> viewModel.selectLayer(id) },
                onUpdateLayer = { layer -> viewModel.updateLayer(layer) },
                onUpdateDrawing = { layerId, segments -> viewModel.updateDrawingSegments(layerId, segments) },
                brushColor = brushColor,
                brushSize = brushSize,
                brushOpacity = brushOpacity,
                isNeonGlow = isNeonGlow,
                isEraser = isEraser,
                isDrawingActive = isDrawingActive
            )
        }
    }

    // Modal Sheets
    if (activeTool == ActiveTool.TEXT) {
        TextEditorSheet(
            selectedLayer = selectedLayer,
            customFonts = customFonts,
            onUpdateLayer = { layer -> viewModel.updateLayer(layer); layer },
            onAddNewText = { text -> viewModel.addTextLayer(text) },
            onImportFont = { name, uri -> viewModel.importCustomFont(name, uri) },
            onDismiss = { activeTool = ActiveTool.NONE }
        )
    }

    if (activeTool == ActiveTool.BRUSH) {
        BrushEditorSheet(
            brushColor = brushColor,
            brushSize = brushSize,
            brushOpacity = brushOpacity,
            isNeonGlow = isNeonGlow,
            isEraser = isEraser,
            onColorChanged = { viewModel.brushColor.value = it },
            onSizeChanged = { viewModel.brushSize.value = it },
            onOpacityChanged = { viewModel.brushOpacity.value = it },
            onNeonGlowChanged = { viewModel.isNeonGlow.value = it },
            onEraserChanged = { viewModel.isEraser.value = it },
            onAddNewDrawLayer = { viewModel.addDrawingLayer() },
            onDismiss = { activeTool = ActiveTool.NONE }
        )
    }

    if (showCutoutSheet || activeTool == ActiveTool.CUTOUT) {
        CutoutSheet(
            onAutoCutout = {
                showCutoutSheet = false
                activeTool = ActiveTool.NONE
            },
            onManualOutline = {
                showCutoutSheet = false
                activeTool = ActiveTool.NONE
            },
            onDismiss = { showCutoutSheet = false; activeTool = ActiveTool.NONE }
        )
    }

    if (activeTool == ActiveTool.SHAPE) {
        ShapeEditorSheet(
            onAddShape = { shapeType -> viewModel.addShapeLayer(shapeType) },
            onDismiss = { activeTool = ActiveTool.NONE }
        )
    }

    if (activeTool == ActiveTool.EFFECTS) {
        EffectsSheet(
            filters = state.filters,
            onUpdateFilters = { filters -> viewModel.updateFilters(filters) },
            onDismiss = { activeTool = ActiveTool.NONE }
        )
    }

    if (showLayersSheet) {
        LayerManagerSheet(
            layers = state.layers,
            selectedLayerId = state.selectedLayerId,
            onSelect = { id -> viewModel.selectLayer(id) },
            onToggleLock = { viewModel.toggleLockSelected() },
            onToggleHide = { viewModel.toggleHideSelected() },
            onDuplicate = { viewModel.duplicateSelectedLayer() },
            onDelete = { viewModel.deleteSelectedLayer() },
            onMoveForward = { viewModel.moveLayerForward() },
            onMoveBackward = { viewModel.moveLayerBackward() },
            onDismiss = { showLayersSheet = false }
        )
    }

    if (showTemplatesSheet || activeTool == ActiveTool.BACKGROUND) {
        TemplateSheet(
            onLoadTemplate = { templateId -> viewModel.loadTemplate(templateId) },
            onDismiss = { showTemplatesSheet = false; activeTool = ActiveTool.NONE }
        )
    }

    if (showExportSheet) {
        ExportSheet(
            onExport = { scale, format -> },
            onDismiss = { showExportSheet = false }
        )
    }
}
