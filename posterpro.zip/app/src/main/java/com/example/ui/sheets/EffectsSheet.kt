package com.example.ui.sheets

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.example.model.FilterConfig

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EffectsSheet(
    filters: FilterConfig,
    onUpdateFilters: (FilterConfig) -> Unit,
    onDismiss: () -> Unit
) {
    var vignette by remember { mutableStateOf(filters.vignette) }
    var contrast by remember { mutableStateOf(filters.contrast) }
    var saturation by remember { mutableStateOf(filters.saturation) }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = Color(0xFF1E1E2C)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(20.dp)
                .navigationBarsPadding(),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text("Canvas Filters & Effects", style = MaterialTheme.typography.titleLarge, color = Color.White)

            Column {
                Text("Vignette: ${(vignette * 100).toInt()}%", color = Color.White)
                Slider(
                    value = vignette,
                    onValueChange = {
                        vignette = it
                        onUpdateFilters(filters.copy(vignette = it))
                    },
                    valueRange = 0f..1f,
                    colors = SliderDefaults.colors(thumbColor = Color(0xFF00E676), activeTrackColor = Color(0xFF00E676))
                )
            }

            Column {
                Text("Contrast: ${String.format("%.2f", contrast)}x", color = Color.White)
                Slider(
                    value = contrast,
                    onValueChange = {
                        contrast = it
                        onUpdateFilters(filters.copy(contrast = it))
                    },
                    valueRange = 0.5f..2.0f,
                    colors = SliderDefaults.colors(thumbColor = Color(0xFF00E676), activeTrackColor = Color(0xFF00E676))
                )
            }

            Column {
                Text("Saturation: ${String.format("%.2f", saturation)}x", color = Color.White)
                Slider(
                    value = saturation,
                    onValueChange = {
                        saturation = it
                        onUpdateFilters(filters.copy(saturation = it))
                    },
                    valueRange = 0.0f..2.0f,
                    colors = SliderDefaults.colors(thumbColor = Color(0xFF00E676), activeTrackColor = Color(0xFF00E676))
                )
            }
        }
    }
}
