package com.example.ui.sheets

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.example.model.Layer

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ImageEditorSheet(
    selectedLayer: Layer?,
    onUpdateLayer: (Layer) -> Unit,
    onDismiss: () -> Unit
) {
    if (selectedLayer == null || selectedLayer.type != com.example.model.LayerType.IMAGE) {
        return
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = Color(0xFF1E1E2C)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
                .navigationBarsPadding(),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text("Photo Adjustment Tools", style = MaterialTheme.typography.titleLarge, color = Color.White)

            // Fit & Fill Buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Button(
                    onClick = {
                        // Fit to canvas
                        onUpdateLayer(selectedLayer.copy(x = 100f, y = 100f, width = 800f, height = 600f, scale = 1f, rotation = 0f))
                        onDismiss()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00E676)),
                    modifier = Modifier.weight(1f)
                ) {
                    Text("Fit to Canvas", color = Color.Black)
                }
                Button(
                    onClick = {
                        // Fill canvas
                        onUpdateLayer(selectedLayer.copy(x = 0f, y = 0f, width = 1280f, height = 720f, scale = 1.2f, rotation = 0f))
                        onDismiss()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2A2A3D)),
                    modifier = Modifier.weight(1f)
                ) {
                    Text("Fill Canvas", color = Color.White)
                }
            }

            // Opacity slider
            Column {
                Text("Photo Opacity: ${(selectedLayer.alpha * 100).toInt()}%", color = Color.White)
                Slider(
                    value = selectedLayer.alpha,
                    onValueChange = { alphaVal ->
                        onUpdateLayer(selectedLayer.copy(alpha = alphaVal))
                    },
                    valueRange = 0.1f..1f,
                    colors = SliderDefaults.colors(thumbColor = Color(0xFF00E676), activeTrackColor = Color(0xFF00E676))
                )
            }

            // Rotation slider
            Column {
                Text("Rotation: ${selectedLayer.rotation.toInt()}°", color = Color.White)
                Slider(
                    value = selectedLayer.rotation,
                    onValueChange = { rotVal ->
                        onUpdateLayer(selectedLayer.copy(rotation = rotVal))
                    },
                    valueRange = -180f..180f,
                    colors = SliderDefaults.colors(thumbColor = Color(0xFF00E676), activeTrackColor = Color(0xFF00E676))
                )
            }
        }
    }
}
