package com.example.ui.sheets

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FontDownload
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.example.model.FontItem
import com.example.model.Layer
import com.example.model.TextConfig

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TextEditorSheet(
    selectedLayer: Layer?,
    customFonts: List<FontItem>,
    onUpdateLayer: (Layer) -> Layer,
    onAddNewText: (String) -> Unit,
    onImportFont: (String, String) -> Unit,
    onDismiss: () -> Unit
) {
    var textValue by remember(selectedLayer) { mutableStateOf(selectedLayer?.textConfig?.text ?: "PosterPro Text") }
    var fontSize by remember(selectedLayer) { mutableStateOf(selectedLayer?.textConfig?.fontSize ?: 48f) }
    var enable3D by remember(selectedLayer) { mutableStateOf(selectedLayer?.textConfig?.enable3D ?: false) }
    var extrusionDepth by remember(selectedLayer) { mutableStateOf(selectedLayer?.textConfig?.extrusionDepth ?: 10f) }
    var curveAngle by remember(selectedLayer) { mutableStateOf(selectedLayer?.textConfig?.curveAngle ?: 0f) }
    var strokeWidth by remember(selectedLayer) { mutableStateOf(selectedLayer?.textConfig?.strokeWidth ?: 0f) }
    var showFontPicker by remember { mutableStateOf(false) }

    val currentFont = selectedLayer?.textConfig?.fontFamily ?: "Roboto"

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = Color(0xFF1E1E2C)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(20.dp)
                .navigationBarsPadding(),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text("Advanced Text Engine & Fonts", style = MaterialTheme.typography.titleLarge, color = Color.White)

            OutlinedTextField(
                value = textValue,
                onValueChange = {
                    textValue = it
                    if (selectedLayer != null) {
                        val tc = selectedLayer.textConfig ?: TextConfig()
                        val updatedTc = tc.copy(text = it)
                        onUpdateLayer(selectedLayer.copy(textConfig = updatedTc))
                    }
                },
                label = { Text("Text Content", color = Color.Gray) },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Color(0xFF00E676),
                    unfocusedBorderColor = Color.Gray,
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White
                ),
                modifier = Modifier.fillMaxWidth()
            )

            // Font Selector Button
            OutlinedButton(
                onClick = { showFontPicker = true },
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Default.FontDownload, contentDescription = null, tint = Color(0xFF00E676))
                Spacer(modifier = Modifier.width(8.dp))
                Text("Font Family: $currentFont", color = Color.White)
            }

            // Font Size
            Column {
                Text("Font Size: ${fontSize.toInt()}sp", color = Color.White)
                Slider(
                    value = fontSize,
                    onValueChange = {
                        fontSize = it
                        if (selectedLayer != null) {
                            val tc = selectedLayer.textConfig ?: TextConfig()
                            onUpdateLayer(selectedLayer.copy(textConfig = tc.copy(fontSize = it)))
                        }
                    },
                    valueRange = 12f..150f,
                    colors = SliderDefaults.colors(thumbColor = Color(0xFF00E676), activeTrackColor = Color(0xFF00E676))
                )
            }

            // 3D Extrusion
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("3D Extrusion Effect", color = Color.White)
                Switch(
                    checked = enable3D,
                    onCheckedChange = {
                        enable3D = it
                        if (selectedLayer != null) {
                            val tc = selectedLayer.textConfig ?: TextConfig()
                            onUpdateLayer(selectedLayer.copy(textConfig = tc.copy(enable3D = it)))
                        }
                    }
                )
            }

            if (enable3D) {
                Column {
                    Text("Extrusion Depth: ${extrusionDepth.toInt()}px", color = Color.White)
                    Slider(
                        value = extrusionDepth,
                        onValueChange = {
                            extrusionDepth = it
                            if (selectedLayer != null) {
                                val tc = selectedLayer.textConfig ?: TextConfig()
                                onUpdateLayer(selectedLayer.copy(textConfig = tc.copy(extrusionDepth = it)))
                            }
                        },
                        valueRange = 2f..30f,
                        colors = SliderDefaults.colors(thumbColor = Color(0xFF00E676), activeTrackColor = Color(0xFF00E676))
                    )
                }
            }

            // Curve Text
            Column {
                Text("Curve / Bend Angle: ${curveAngle.toInt()}°", color = Color.White)
                Slider(
                    value = curveAngle,
                    onValueChange = {
                        curveAngle = it
                        if (selectedLayer != null) {
                            val tc = selectedLayer.textConfig ?: TextConfig()
                            onUpdateLayer(selectedLayer.copy(textConfig = tc.copy(curveAngle = it)))
                        }
                    },
                    valueRange = -180f..180f,
                    colors = SliderDefaults.colors(thumbColor = Color(0xFF00E676), activeTrackColor = Color(0xFF00E676))
                )
            }

            // Stroke
            Column {
                Text("Stroke Width: ${strokeWidth.toInt()}px", color = Color.White)
                Slider(
                    value = strokeWidth,
                    onValueChange = {
                        strokeWidth = it
                        if (selectedLayer != null) {
                            val tc = selectedLayer.textConfig ?: TextConfig()
                            onUpdateLayer(selectedLayer.copy(textConfig = tc.copy(strokeWidth = it)))
                        }
                    },
                    valueRange = 0f..20f,
                    colors = SliderDefaults.colors(thumbColor = Color(0xFF00E676), activeTrackColor = Color(0xFF00E676))
                )
            }

            if (selectedLayer == null) {
                Button(
                    onClick = { onAddNewText(textValue); onDismiss() },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00E676)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Add New Text Layer", color = Color.Black)
                }
            }
        }
    }

    if (showFontPicker) {
        FontPickerSheet(
            currentFontName = currentFont,
            customFonts = customFonts,
            onSelectFont = { fontName ->
                if (selectedLayer != null) {
                    val tc = selectedLayer.textConfig ?: TextConfig()
                    onUpdateLayer(selectedLayer.copy(textConfig = tc.copy(fontFamily = fontName)))
                }
            },
            onImportFont = { name, uri ->
                onImportFont(name, uri)
            },
            onDismiss = { showFontPicker = false }
        )
    }
}
