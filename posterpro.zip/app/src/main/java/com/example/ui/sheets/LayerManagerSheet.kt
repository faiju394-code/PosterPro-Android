package com.example.ui.sheets

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.example.model.Layer

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LayerManagerSheet(
    layers: List<Layer>,
    selectedLayerId: String?,
    onSelect: (String?) -> Unit,
    onToggleLock: () -> Unit,
    onToggleHide: () -> Unit,
    onDuplicate: () -> Unit,
    onDelete: () -> Unit,
    onMoveForward: () -> Unit,
    onMoveBackward: () -> Unit,
    onDismiss: () -> Unit
) {
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = Color(0xFF1E1E2C)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .navigationBarsPadding()
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Layers Manager", style = MaterialTheme.typography.titleLarge, color = Color.White)
                Row {
                    IconButton(onClick = onMoveBackward) {
                        Icon(Icons.Default.ArrowDownward, contentDescription = "Send Backward", tint = Color.White)
                    }
                    IconButton(onClick = onMoveForward) {
                        Icon(Icons.Default.ArrowUpward, contentDescription = "Bring Forward", tint = Color.White)
                    }
                    IconButton(onClick = onDuplicate) {
                        Icon(Icons.Default.ContentCopy, contentDescription = "Duplicate", tint = Color.White)
                    }
                    IconButton(onClick = onDelete) {
                        Icon(Icons.Default.Delete, contentDescription = "Delete", tint = Color.Red)
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            if (layers.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(200.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text("No layers added yet.", color = Color.Gray)
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(350.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(layers.reversed()) { layer ->
                        val isSelected = layer.id == selectedLayerId
                        Card(
                            colors = CardDefaults.cardColors(
                                containerColor = if (isSelected) Color(0xFF2D3748) else Color(0xFF2A2A3D)
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onSelect(layer.id) }
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                    Icon(
                                        imageVector = when (layer.type) {
                                            com.example.model.LayerType.TEXT -> Icons.Default.TextFields
                                            com.example.model.LayerType.SHAPE -> Icons.Default.Category
                                            com.example.model.LayerType.IMAGE -> Icons.Default.Image
                                            else -> Icons.Default.Star
                                        },
                                        contentDescription = null,
                                        tint = if (isSelected) Color(0xFF00E676) else Color.White
                                    )
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Text(
                                        text = layer.name,
                                        color = Color.White,
                                        style = MaterialTheme.typography.bodyMedium
                                    )
                                }
                                Row {
                                    IconButton(onClick = onToggleLock) {
                                        Icon(
                                            imageVector = if (layer.isLocked) Icons.Default.Lock else Icons.Default.LockOpen,
                                            contentDescription = "Lock",
                                            tint = if (layer.isLocked) Color(0xFFFF5252) else Color.Gray
                                        )
                                    }
                                    IconButton(onClick = onToggleHide) {
                                        Icon(
                                            imageVector = if (layer.isHidden) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                            contentDescription = "Visibility",
                                            tint = if (layer.isHidden) Color.Gray else Color(0xFF00E676)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
