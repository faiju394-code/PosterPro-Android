package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp

enum class ActiveTool {
    NONE, TEXT, SHAPE, STICKER, IMAGE, BRUSH, CUTOUT, EFFECTS, BACKGROUND
}

@Composable
fun BottomToolbar(
    activeTool: ActiveTool,
    onToolSelected: (ActiveTool) -> Unit
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        color = Color(0xFF1E1E2C),
        tonalElevation = 8.dp
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 8.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            ToolButton(
                icon = Icons.Default.TextFields,
                label = "Text",
                isSelected = activeTool == ActiveTool.TEXT,
                onClick = { onToolSelected(ActiveTool.TEXT) }
            )
            ToolButton(
                icon = Icons.Default.Category,
                label = "Shapes",
                isSelected = activeTool == ActiveTool.SHAPE,
                onClick = { onToolSelected(ActiveTool.SHAPE) }
            )
            ToolButton(
                icon = Icons.Default.Brush,
                label = "Brush",
                isSelected = activeTool == ActiveTool.BRUSH,
                onClick = { onToolSelected(ActiveTool.BRUSH) }
            )
            ToolButton(
                icon = Icons.Default.ContentCut,
                label = "Cutout",
                isSelected = activeTool == ActiveTool.CUTOUT,
                onClick = { onToolSelected(ActiveTool.CUTOUT) }
            )
            ToolButton(
                icon = Icons.Default.Star,
                label = "Stickers",
                isSelected = activeTool == ActiveTool.STICKER,
                onClick = { onToolSelected(ActiveTool.STICKER) }
            )
            ToolButton(
                icon = Icons.Default.Image,
                label = "Image",
                isSelected = activeTool == ActiveTool.IMAGE,
                onClick = { onToolSelected(ActiveTool.IMAGE) }
            )
            ToolButton(
                icon = Icons.Default.AutoFixHigh,
                label = "Effects",
                isSelected = activeTool == ActiveTool.EFFECTS,
                onClick = { onToolSelected(ActiveTool.EFFECTS) }
            )
            ToolButton(
                icon = Icons.Default.ColorLens,
                label = "Background",
                isSelected = activeTool == ActiveTool.BACKGROUND,
                onClick = { onToolSelected(ActiveTool.BACKGROUND) }
            )
        }
    }
}

@Composable
fun ToolButton(
    icon: ImageVector,
    label: String,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.padding(horizontal = 4.dp)
    ) {
        IconButton(
            onClick = onClick,
            colors = IconButtonDefaults.iconButtonColors(
                containerColor = if (isSelected) Color(0xFF00E676) else Color(0xFF2D2D44),
                contentColor = if (isSelected) Color.Black else Color.White
            )
        ) {
            Icon(icon, contentDescription = label)
        }
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = if (isSelected) Color(0xFF00E676) else Color.White
        )
    }
}
