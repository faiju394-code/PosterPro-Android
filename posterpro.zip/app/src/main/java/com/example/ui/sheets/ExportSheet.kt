package com.example.ui.sheets

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ExportSheet(
    onExport: (Int, String) -> Unit,
    onDismiss: () -> Unit
) {
    var scaleFactor by remember { mutableStateOf(2) } // 1x, 2x, 4x Ultra
    var format by remember { mutableStateOf("PNG") }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = Color(0xFF1E1E2C)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
                .navigationBarsPadding(),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text("Export Studio Creation", style = MaterialTheme.typography.titleLarge, color = Color.White)

            Text("Resolution Quality Preset", style = MaterialTheme.typography.bodyMedium, color = Color.Gray)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Button(
                    onClick = { scaleFactor = 1 },
                    colors = ButtonDefaults.buttonColors(containerColor = if (scaleFactor == 1) Color(0xFF00E676) else Color(0xFF2A2A3D)),
                    modifier = Modifier.weight(1f)
                ) {
                    Text("1x Standard", color = if (scaleFactor == 1) Color.Black else Color.White)
                }
                Button(
                    onClick = { scaleFactor = 2 },
                    colors = ButtonDefaults.buttonColors(containerColor = if (scaleFactor == 2) Color(0xFF00E676) else Color(0xFF2A2A3D)),
                    modifier = Modifier.weight(1f)
                ) {
                    Text("2x HD", color = if (scaleFactor == 2) Color.Black else Color.White)
                }
                Button(
                    onClick = { scaleFactor = 4 },
                    colors = ButtonDefaults.buttonColors(containerColor = if (scaleFactor == 4) Color(0xFF00E676) else Color(0xFF2A2A3D)),
                    modifier = Modifier.weight(1f)
                ) {
                    Text("4x Ultra 4K", color = if (scaleFactor == 4) Color.Black else Color.White)
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Button(
                onClick = {
                    onExport(scaleFactor, format)
                    onDismiss()
                },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00E676)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Export & Save to Gallery", color = Color.Black)
            }
        }
    }
}
