package com.example.ui.components

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Redo
import androidx.compose.material.icons.automirrored.filled.Undo
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.graphics.Color

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TopToolbar(
    onUndo: () -> Unit,
    onRedo: () -> Unit,
    onOpenLayers: () -> Unit,
    onOpenTemplates: () -> Unit,
    onOpenExport: () -> Unit,
    onBack: () -> Unit
) {
    TopAppBar(
        title = {
            Text("PosterPro Studio", style = MaterialTheme.typography.titleMedium, color = Color.White)
        },
        navigationIcon = {
            IconButton(onClick = onBack) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
            }
        },
        actions = {
            IconButton(onClick = onUndo) {
                Icon(Icons.AutoMirrored.Filled.Undo, contentDescription = "Undo", tint = Color.White)
            }
            IconButton(onClick = onRedo) {
                Icon(Icons.AutoMirrored.Filled.Redo, contentDescription = "Redo", tint = Color.White)
            }
            IconButton(onClick = onOpenTemplates) {
                Icon(Icons.Default.Dashboard, contentDescription = "Templates", tint = Color.White)
            }
            IconButton(onClick = onOpenLayers) {
                Icon(Icons.Default.Layers, contentDescription = "Layers", tint = Color.White)
            }
            IconButton(onClick = onOpenExport) {
                Icon(Icons.Default.Download, contentDescription = "Export", tint = Color.White)
            }
        },
        colors = TopAppBarDefaults.topAppBarColors(containerColor = Color(0xFF1E1E2C))
    )
}
