package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.model.CanvasRatio

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    onStartBlank: (CanvasRatio) -> Unit,
    onOpenTemplate: (String) -> Unit
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("PosterPro Studio", fontWeight = FontWeight.Bold, color = Color.White) },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color(0xFF1E1E2C))
            )
        },
        containerColor = Color(0xFF12121A)
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            Text("Choose Canvas Aspect Ratio", style = MaterialTheme.typography.titleMedium, color = Color.Gray)

            val ratios = listOf(
                CanvasRatio.YOUTUBE_THUMBNAIL,
                CanvasRatio.INSTAGRAM_POST,
                CanvasRatio.INSTAGRAM_PORTRAIT,
                CanvasRatio.INSTAGRAM_STORY,
                CanvasRatio.YOUTUBE_BANNER,
                CanvasRatio.CUSTOM
            )

            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(ratios) { ratio ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1E2C)),
                        onClick = { onStartBlank(ratio) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(100.dp)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(16.dp),
                            verticalArrangement = Arrangement.Center
                        ) {
                            Text(ratio.title, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold, color = Color.White)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text("${ratio.width} x ${ratio.height} px", style = MaterialTheme.typography.labelSmall, color = Color(0xFF00E676))
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text("Quick Professional Templates", style = MaterialTheme.typography.titleMedium, color = Color.Gray)

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Button(
                    onClick = { onOpenTemplate("cyberpunk") },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E1A47)),
                    modifier = Modifier.weight(1f)
                ) {
                    Text("Cyberpunk", color = Color(0xFF00FFFF))
                }
                Button(
                    onClick = { onOpenTemplate("sale") },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF4A1525)),
                    modifier = Modifier.weight(1f)
                ) {
                    Text("Mega Sale", color = Color(0xFFFF3366))
                }
            }
        }
    }
}
