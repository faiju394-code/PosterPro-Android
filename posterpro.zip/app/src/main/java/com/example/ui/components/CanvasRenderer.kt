package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import com.example.model.*

@Composable
fun CanvasRenderer(
    state: CanvasState,
    onSelectLayer: (String?) -> Unit,
    onUpdateLayer: (Layer) -> Unit,
    onUpdateDrawing: (String, List<DrawSegment>) -> Unit,
    brushColor: Long,
    brushSize: Float,
    brushOpacity: Float,
    isNeonGlow: Boolean,
    isEraser: Boolean,
    isDrawingActive: Boolean,
    modifier: Modifier = Modifier
) {
    BoxWithConstraints(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF222222))
    ) {
        val availableWidth = constraints.maxWidth.toFloat()
        val availableHeight = constraints.maxHeight.toFloat()

        val canvasW = if (state.ratio == CanvasRatio.CUSTOM) state.customWidth.toFloat() else state.ratio.width.toFloat()
        val canvasH = if (state.ratio == CanvasRatio.CUSTOM) state.customHeight.toFloat() else state.ratio.height.toFloat()

        val scaleX = availableWidth / canvasW
        val scaleY = availableHeight / canvasH
        val renderScale = minOf(scaleX, scaleY) * 0.85f

        val renderW = canvasW * renderScale
        val renderH = canvasH * renderScale
        val offsetX = (availableWidth - renderW) / 2f
        val offsetY = (availableHeight - renderH) / 2f

        var currentSegmentPoints by remember { mutableStateOf<MutableList<OffsetData>>(mutableListOf()) }

        Box(
            modifier = Modifier
                .offset(offsetX.toDp(), offsetY.toDp())
                .size(renderW.toDp(), renderH.toDp())
                .pointerInput(isDrawingActive, state.selectedLayerId) {
                    if (isDrawingActive) {
                        detectDragGestures(
                            onDragStart = { offset ->
                                val x = offset.x / renderScale
                                val y = offset.y / renderScale
                                currentSegmentPoints = mutableListOf(OffsetData(x, y))
                            },
                            onDrag = { change, _ ->
                                change.consume()
                                val x = change.position.x / renderScale
                                val y = change.position.y / renderScale
                                currentSegmentPoints.add(OffsetData(x, y))
                            },
                            onDragEnd = {
                                val selectedLayer = state.layers.find { it.id == state.selectedLayerId }
                                if (selectedLayer != null && selectedLayer.type == LayerType.DRAWING && currentSegmentPoints.isNotEmpty()) {
                                    val dc = selectedLayer.drawingConfig ?: DrawingConfig()
                                    val newSegment = DrawSegment(
                                        points = currentSegmentPoints.toList(),
                                        color = brushColor,
                                        strokeWidth = brushSize,
                                        isNeon = isNeonGlow,
                                        isEraser = isEraser
                                    )
                                    onUpdateDrawing(selectedLayer.id, dc.segments + newSegment)
                                    currentSegmentPoints = mutableListOf()
                                }
                            }
                        )
                    } else {
                        detectTransformGestures { _, pan, zoom, rotationChange ->
                            val selectedId = state.selectedLayerId ?: return@detectTransformGestures
                            val layer = state.layers.find { it.id == selectedId } ?: return@detectTransformGestures
                            if (layer.isLocked) return@detectTransformGestures

                            val newX = layer.x + pan.x / renderScale
                            val newY = layer.y + pan.y / renderScale
                            val newScale = (layer.scale * zoom).coerceIn(0.1f, 5f)
                            val newRotation = layer.rotation + rotationChange

                            onUpdateLayer(layer.copy(x = newX, y = newY, scale = newScale, rotation = newRotation))
                        }
                    }
                }
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val scaleFactor = renderScale
                withTransform({
                    scale(scaleFactor, scaleFactor, pivot = Offset.Zero)
                }) {
                    drawCanvasBackground(state, canvasW, canvasH)

                    for (layer in state.layers) {
                        if (layer.isHidden) continue
                        drawLayer(layer)
                    }

                    if (currentSegmentPoints.size >= 2) {
                        val path = Path().apply {
                            moveTo(currentSegmentPoints[0].x, currentSegmentPoints[0].y)
                            for (p in currentSegmentPoints.drop(1)) {
                                lineTo(p.x, p.y)
                            }
                        }
                        if (isNeonGlow) {
                            drawPath(
                                path = path,
                                color = Color(brushColor).copy(alpha = 0.5f),
                                style = Stroke(width = brushSize * 2f, cap = StrokeCap.Round, join = StrokeJoin.Round)
                            )
                        }
                        drawPath(
                            path = path,
                            color = if (isEraser) Color.Transparent else Color(brushColor).copy(alpha = brushOpacity),
                            style = Stroke(width = brushSize, cap = StrokeCap.Round, join = StrokeJoin.Round)
                        )
                    }

                    drawCanvasFilters(state.filters, canvasW, canvasH)
                }
            }

            state.selectedLayerId?.let { selectedId ->
                val layer = state.layers.find { it.id == selectedId }
                if (layer != null && !layer.isHidden && layer.type != LayerType.DRAWING) {
                    val selX = layer.x * renderScale
                    val selY = layer.y * renderScale
                    val selW = layer.width * layer.scale * renderScale
                    val selH = layer.height * layer.scale * renderScale

                    Box(
                        modifier = Modifier
                            .offset(selX.toDp(), selY.toDp())
                            .size(selW.toDp(), selH.toDp())
                            .border(2.dp, Color(0xFF00E676), androidx.compose.foundation.shape.RoundedCornerShape(4.dp))
                    )
                }
            }
        }
    }
}

private fun DrawScope.drawCanvasBackground(state: CanvasState, width: Float, height: Float) {
    when (state.backgroundType) {
        BackgroundType.TRANSPARENT -> {
            val tileSize = 40f
            var isDark = false
            for (x in 0..width.toInt() step tileSize.toInt()) {
                for (y in 0..height.toInt() step tileSize.toInt()) {
                    drawRect(
                        color = if (isDark) Color(0xFF333333) else Color(0xFF444444),
                        topLeft = Offset(x.toFloat(), y.toFloat()),
                        size = Size(tileSize, tileSize)
                    )
                    isDark = !isDark
                }
            }
        }
        BackgroundType.SOLID -> {
            drawRect(color = Color(state.backgroundColor), size = Size(width, height))
        }
        BackgroundType.GRADIENT -> {
            drawRect(
                brush = Brush.linearGradient(
                    colors = listOf(Color(state.backgroundColor), Color(state.backgroundGradientEnd)),
                    start = Offset(0f, 0f),
                    end = Offset(width, height)
                ),
                size = Size(width, height)
            )
        }
        BackgroundType.IMAGE -> {
            drawRect(color = Color(state.backgroundColor), size = Size(width, height))
        }
    }
}

private fun DrawScope.drawLayer(layer: Layer) {
    withTransform({
        translate(layer.x, layer.y)
        rotate(layer.rotation, pivot = Offset(layer.width / 2f, layer.height / 2f))
        scale(layer.scale, layer.scale, pivot = Offset(layer.width / 2f, layer.height / 2f))
    }) {
        when (layer.type) {
            LayerType.TEXT -> {
                val tc = layer.textConfig ?: TextConfig()
                drawRect(
                    color = Color(0x33FFFFFF),
                    size = Size(layer.width, layer.height)
                )
                drawRect(
                    color = Color(tc.textColor),
                    size = Size(layer.width, layer.height),
                    style = Stroke(width = if (tc.strokeWidth > 0f) tc.strokeWidth else 2f)
                )
            }
            LayerType.SHAPE -> {
                val sc = layer.shapeConfig ?: ShapeConfig()
                val color = Color(sc.fillColor)
                val strokeColor = Color(sc.strokeColor)
                val strokeWidth = sc.strokeWidth
                val radius = sc.cornerRadius

                when (sc.shapeType) {
                    ShapeType.RECTANGLE -> {
                        drawRoundRect(
                            color = color,
                            size = Size(layer.width, layer.height),
                            cornerRadius = androidx.compose.ui.geometry.CornerRadius(radius, radius)
                        )
                        if (strokeWidth > 0f) {
                            drawRoundRect(
                                color = strokeColor,
                                size = Size(layer.width, layer.height),
                                cornerRadius = androidx.compose.ui.geometry.CornerRadius(radius, radius),
                                style = Stroke(width = strokeWidth)
                            )
                        }
                    }
                    ShapeType.CIRCLE -> {
                        val radiusVal = minOf(layer.width, layer.height) / 2f
                        drawCircle(
                            color = color,
                            radius = radiusVal,
                            center = Offset(layer.width / 2f, layer.height / 2f)
                        )
                        if (strokeWidth > 0f) {
                            drawCircle(
                                color = strokeColor,
                                radius = radiusVal,
                                center = Offset(layer.width / 2f, layer.height / 2f),
                                style = Stroke(width = strokeWidth)
                            )
                        }
                    }
                    else -> {
                        drawRect(color = color, size = Size(layer.width, layer.height))
                    }
                }
            }
            LayerType.DRAWING -> {
                val dc = layer.drawingConfig ?: DrawingConfig()
                for (seg in dc.segments) {
                    if (seg.points.size < 2) continue
                    val path = Path().apply {
                        moveTo(seg.points[0].x, seg.points[0].y)
                        for (p in seg.points.drop(1)) {
                            lineTo(p.x, p.y)
                        }
                    }
                    if (seg.isNeon) {
                        drawPath(
                            path = path,
                            color = Color(seg.color).copy(alpha = 0.5f),
                            style = Stroke(width = seg.strokeWidth * 2f, cap = StrokeCap.Round, join = StrokeJoin.Round)
                        )
                    }
                    drawPath(
                        path = path,
                        color = if (seg.isEraser) Color.Transparent else Color(seg.color),
                        style = Stroke(width = seg.strokeWidth, cap = StrokeCap.Round, join = StrokeJoin.Round)
                    )
                }
            }
            LayerType.STICKER -> {
                drawRect(
                    color = Color(0xFFFF4081),
                    size = Size(layer.width, layer.height)
                )
            }
            else -> {}
        }
    }
}

private fun DrawScope.drawCanvasFilters(filters: FilterConfig, width: Float, height: Float) {
    if (filters.vignette > 0f) {
        val gradient = Brush.radialGradient(
            colors = listOf(Color.Transparent, Color.Black.copy(alpha = filters.vignette)),
            center = Offset(width / 2f, height / 2f),
            radius = maxOf(width, height) * 0.7f
        )
        drawRect(brush = gradient, size = Size(width, height))
    }
}

private fun Float.toDp() = androidx.compose.ui.unit.Dp(this)
