package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.rememberAsyncImagePainter
import com.example.R
import com.example.model.*

@Composable
fun CanvasRenderer(
    state: CanvasState,
    onSelectLayer: (String?) -> Unit,
    onUpdateLayer: (Layer) -> Unit,
    onUpdateDrawing: (String, List<DrawSegment>) -> Unit,
    brushColor: Long,
    brushSize: Float,
    brushOpacity: Float,
    isNeonGlow: Boolean,
    isEraser: Boolean,
    isDrawingActive: Boolean,
    modifier: Modifier = Modifier
) {
    BoxWithConstraints(
        modifier = modifier
            .fillMaxSize()
            .background(
                brush = when (state.backgroundType) {
                    BackgroundType.SOLID -> Brush.linearGradient(listOf(Color(state.backgroundColor), Color(state.backgroundColor)))
                    BackgroundType.GRADIENT -> Brush.linearGradient(
                        colors = listOf(Color(state.backgroundColor), Color(state.backgroundGradientEnd)),
                        start = Offset(0f, 0f),
                        end = Offset(1000f, 1000f)
                    )
                    BackgroundType.TRANSPARENT -> Brush.linearGradient(listOf(Color(0xFF333333), Color(0xFF444444)))
                    else -> Brush.linearGradient(listOf(Color(state.backgroundColor), Color(state.backgroundColor)))
                }
            )
    ) {
        val availableWidth = constraints.maxWidth.toFloat()
        val availableHeight = constraints.maxHeight.toFloat()

        val canvasW = if (state.ratio == CanvasRatio.CUSTOM) state.customWidth.toFloat() else state.ratio.width.toFloat()
        val canvasH = if (state.ratio == CanvasRatio.CUSTOM) state.customHeight.toFloat() else state.ratio.height.toFloat()

        val scaleX = availableWidth / canvasW
        val scaleY = availableHeight / canvasH
        val renderScale = minOf(scaleX, scaleY) * 0.85f

        val renderW = canvasW * renderScale
        val renderH = canvasH * renderScale
        val offsetX = (availableWidth - renderW) / 2f
        val offsetY = (availableHeight - renderH) / 2f

        var currentSegmentPoints by remember { mutableStateOf<MutableList<OffsetData>>(mutableListOf()) }

        Box(
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(isDrawingActive, state.selectedLayerId) {
                    if (isDrawingActive) {
                        detectDragGestures(
                            onDragStart = { offset ->
                                val x = offset.x / renderScale
                                val y = offset.y / renderScale
                                currentSegmentPoints = mutableListOf(OffsetData(x, y))
                            },
                            onDrag = { change, _ ->
                                change.consume()
                                val x = change.position.x / renderScale
                                val y = change.position.y / renderScale
                                currentSegmentPoints.add(OffsetData(x, y))
                            },
                            onDragEnd = {
                                val selectedLayer = state.layers.find { it.id == state.selectedLayerId }
                                if (selectedLayer != null && selectedLayer.type == LayerType.DRAWING && currentSegmentPoints.isNotEmpty()) {
                                    val dc = selectedLayer.drawingConfig ?: DrawingConfig()
                                    val newSegment = DrawSegment(
                                        points = currentSegmentPoints.toList(),
                                        color = brushColor,
                                        strokeWidth = brushSize,
                                        isNeon = isNeonGlow,
                                        isEraser = isEraser
                                    )
                                    onUpdateDrawing(selectedLayer.id, dc.segments + newSegment)
                                    currentSegmentPoints = mutableListOf()
                                }
                            }
                        )
                    } else {
                        detectTransformGestures { _, pan, zoom, rotationChange ->
                            val selectedId = state.selectedLayerId ?: return@detectTransformGestures
                            val layer = state.layers.find { it.id == selectedId } ?: return@detectTransformGestures
                            if (layer.isLocked) return@detectTransformGestures

                            val newX = layer.x + pan.x / renderScale
                            val newY = layer.y + pan.y / renderScale
                            val newScale = (layer.scale * zoom).coerceIn(0.1f, 5f)
                            val newRotation = layer.rotation + rotationChange

                            onUpdateLayer(layer.copy(x = newX, y = newY, scale = newScale, rotation = newRotation))
                        }
                    }
                }
        ) {
            if (state.backgroundType == BackgroundType.IMAGE && !state.backgroundImageUri.isNullOrEmpty()) {
                Image(
                    painter = rememberAsyncImagePainter(model = state.backgroundImageUri),
                    contentDescription = "Canvas Background Image",
                    contentScale = ContentScale.FillBounds,
                    modifier = Modifier.fillMaxSize()
                )
            }

            Box(
                modifier = Modifier
                    .offset(offsetX.toDp(), offsetY.toDp())
                    .size(renderW.toDp(), renderH.toDp())
            ) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val scaleFactor = renderScale
                    withTransform({
                        scale(scaleFactor, scaleFactor, pivot = Offset.Zero)
                    }) {
                        for (layer in state.layers) {
                            if (layer.isHidden) continue
                            drawLayer(layer)
                        }

                        if (currentSegmentPoints.size >= 2) {
                            val path = Path().apply {
                                moveTo(currentSegmentPoints[0].x, currentSegmentPoints[0].y)
                                for (p in currentSegmentPoints.drop(1)) {
                                    lineTo(p.x, p.y)
                                }
                            }
                            if (isNeonGlow) {
                                drawPath(
                                    path = path,
                                    color = Color(brushColor).copy(alpha = 0.5f),
                                    style = Stroke(width = brushSize * 2f, cap = StrokeCap.Round, join = StrokeJoin.Round)
                                )
                            }
                            drawPath(
                                path = path,
                                color = if (isEraser) Color.Transparent else Color(brushColor).copy(alpha = brushOpacity),
                                style = Stroke(width = brushSize, cap = StrokeCap.Round, join = StrokeJoin.Round)
                            )
                        }

                        drawCanvasFilters(state.filters, canvasW, canvasH)
                    }
                }

                // Render Text Layers with touch selection support
                for (layer in state.layers) {
                    if (layer.isHidden || layer.type != LayerType.TEXT || layer.textConfig == null) continue
                    val tc = layer.textConfig
                    val layerX = layer.x * renderScale
                    val layerY = layer.y * renderScale
                    val layerW = layer.width * layer.scale * renderScale
                    val layerH = layer.height * layer.scale * renderScale

                    val fontFamily = when (tc.fontFamily.lowercase()) {
                        "pacifico" -> FontFamily(Font(R.font.pacifico))
                        "caveat" -> FontFamily(Font(R.font.caveat))
                        "great vibes" -> FontFamily(Font(R.font.great_vibes))
                        "dancing script" -> FontFamily(Font(R.font.dancing_script))
                        "roboto" -> FontFamily(Font(R.font.roboto))
                        "noto sans devanagari" -> FontFamily(Font(R.font.noto_sans_devanagari))
                        "noto sans bengali" -> FontFamily(Font(R.font.noto_sans_bengali))
                        "noto sans tamil" -> FontFamily(Font(R.font.noto_sans_tamil))
                        "noto sans telugu" -> FontFamily(Font(R.font.noto_sans_telugu))
                        "noto sans arabic" -> FontFamily(Font(R.font.noto_sans_arabic))
                        "tiro bangla (assamese)" -> FontFamily(Font(R.font.tiro_bangla))
                        "noto serif bengali (assamese)" -> FontFamily(Font(R.font.noto_serif_bengali))
                        else -> FontFamily.Default
                    }

                    Box(
                        modifier = Modifier
                            .offset(layerX.toDp(), layerY.toDp())
                            .size(layerW.toDp(), layerH.toDp())
                            .graphicsLayer(
                                rotationZ = layer.rotation,
                                alpha = layer.alpha
                            )
                            .clickable { onSelectLayer(layer.id) },
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = tc.text,
                            color = Color(tc.textColor),
                            fontSize = (tc.fontSize * renderScale).sp,
                            fontFamily = fontFamily,
                            textAlign = TextAlign.Center
                        )
                    }
                }

                // Render Image Layers with touch selection and interactive gestures
                for (layer in state.layers) {
                    if (layer.isHidden || layer.type != LayerType.IMAGE || layer.imageUri == null) continue
                    val painter = rememberAsyncImagePainter(model = layer.imageUri)
                    val layerX = layer.x * renderScale
                    val layerY = layer.y * renderScale
                    val layerW = layer.width * layer.scale * renderScale
                    val layerH = layer.height * layer.scale * renderScale

                    Box(
                        modifier = Modifier
                            .offset(layerX.toDp(), layerY.toDp())
                            .size(layerW.toDp(), layerH.toDp())
                            .graphicsLayer(
                                rotationZ = layer.rotation,
                                alpha = layer.alpha
                            )
                            .clickable { onSelectLayer(layer.id) }
                    ) {
                        Image(
                            painter = painter,
                            contentDescription = layer.name,
                            contentScale = ContentScale.FillBounds,
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                }

                state.selectedLayerId?.let { selectedId ->
                    val layer = state.layers.find { it.id == selectedId }
                    if (layer != null && !layer.isHidden && layer.type != LayerType.DRAWING) {
                        val selX = layer.x * renderScale
                        val selY = layer.y * renderScale
                        val selW = layer.width * layer.scale * renderScale
                        val selH = layer.height * layer.scale * renderScale

                        Box(
                            modifier = Modifier
                                .offset(selX.toDp(), selY.toDp())
                                .size(selW.toDp(), selH.toDp())
                                .border(2.dp, Color(0xFF00E676), androidx.compose.foundation.shape.RoundedCornerShape(4.dp))
                        )
                    }
                }
            }
        }
    }
}

private fun DrawScope.drawLayer(layer: Layer) {
    withTransform({
        translate(layer.x, layer.y)
        rotate(layer.rotation, pivot = Offset(layer.width / 2f, layer.height / 2f))
        scale(layer.scale, layer.scale, pivot = Offset(layer.width / 2f, layer.height / 2f))
    }) {
        when (layer.type) {
            LayerType.SHAPE -> {
                val sc = layer.shapeConfig ?: ShapeConfig()
                val color = Color(sc.fillColor)
                val strokeColor = Color(sc.strokeColor)
                val strokeWidth = sc.strokeWidth
                val radius = sc.cornerRadius

                when (sc.shapeType) {
                    ShapeType.RECTANGLE -> {
                        drawRoundRect(
                            color = color,
                            size = Size(layer.width, layer.height),
                            cornerRadius = androidx.compose.ui.geometry.CornerRadius(radius, radius)
                        )
                        if (strokeWidth > 0f) {
                            drawRoundRect(
                                color = strokeColor,
                                size = Size(layer.width, layer.height),
                                cornerRadius = androidx.compose.ui.geometry.CornerRadius(radius, radius),
                                style = Stroke(width = strokeWidth)
                            )
                        }
                    }
                    ShapeType.CIRCLE -> {
                        val radiusVal = minOf(layer.width, layer.height) / 2f
                        drawCircle(
                            color = color,
                            radius = radiusVal,
                            center = Offset(layer.width / 2f, layer.height / 2f)
                        )
                        if (strokeWidth > 0f) {
                            drawCircle(
                                color = strokeColor,
                                radius = radiusVal,
                                center = Offset(layer.width / 2f, layer.height / 2f),
                                style = Stroke(width = strokeWidth)
                            )
                        }
                    }
                    else -> {
                        drawRect(color = color, size = Size(layer.width, layer.height))
                    }
                }
            }
            LayerType.DRAWING -> {
                val dc = layer.drawingConfig ?: DrawingConfig()
                for (seg in dc.segments) {
                    if (seg.points.size < 2) continue
                    val path = Path().apply {
                        moveTo(seg.points[0].x, seg.points[0].y)
                        for (p in seg.points.drop(1)) {
                            lineTo(p.x, p.y)
                        }
                    }
                    if (seg.isNeon) {
                        drawPath(
                            path = path,
                            color = Color(seg.color).copy(alpha = 0.5f),
                            style = Stroke(width = seg.strokeWidth * 2f, cap = StrokeCap.Round, join = StrokeJoin.Round)
                        )
                    }
                    drawPath(
                        path = path,
                        color = if (seg.isEraser) Color.Transparent else Color(seg.color),
                        style = Stroke(width = seg.strokeWidth, cap = StrokeCap.Round, join = StrokeJoin.Round)
                    )
                }
            }
            LayerType.STICKER -> {
                drawRect(
                    color = Color(0xFFFF4081),
                    size = Size(layer.width, layer.height)
                )
            }
            else -> {}
        }
    }
}

private fun DrawScope.drawCanvasFilters(filters: FilterConfig, width: Float, height: Float) {
    if (filters.vignette > 0f) {
        val gradient = Brush.radialGradient(
            colors = listOf(Color.Transparent, Color.Black.copy(alpha = filters.vignette)),
            center = Offset(width / 2f, height / 2f),
            radius = maxOf(width, height) * 0.7f
        )
        drawRect(brush = gradient, size = Size(width, height))
    }
}

private fun Float.toDp() = androidx.compose.ui.unit.Dp(this)
