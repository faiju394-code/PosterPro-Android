package com.example.ui.sheets

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TemplateSheet(
    onLoadTemplate: (String) -> Unit,
    onDismiss: () -> Unit
) {
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = Color(0xFF1E1E2C)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
                .navigationBarsPadding(),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text("Professional Templates Library", style = MaterialTheme.typography.titleLarge, color = Color.White)

            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(300.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item {
                    TemplateCard(
                        title = "Cyberpunk Thumbnail",
                        description = "Futuristic neon 3D text and gradient background for YouTube/Gaming",
                        onClick = { onLoadTemplate("cyberpunk"); onDismiss() }
                    )
                }
                item {
                    TemplateCard(
                        title = "Mega Sale Post",
                        description = "High-conversion e-commerce promotional banner for Instagram",
                        onClick = { onLoadTemplate("sale"); onDismiss() }
                    )
                }
                item {
                    TemplateCard(
                        title = "Minimalist Quote",
                        description = "Clean typography layout for inspirational or editorial stories",
                        onClick = { onLoadTemplate("quote"); onDismiss() }
                    )
                }
            }
        }
    }
}

@Composable
fun TemplateCard(title: String, description: String, onClick: () -> Unit) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color(0xFF2A2A3D)),
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium, color = Color(0xFF00E676))
            Spacer(modifier = Modifier.height(4.dp))
            Text(description, style = MaterialTheme.typography.bodySmall, color = Color.LightGray)
        }
    }
}
